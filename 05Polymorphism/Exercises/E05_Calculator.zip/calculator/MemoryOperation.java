package calculator;

import java.util.ArrayDeque;

public class MemoryOperation implements Operation {
    private ArrayDeque<Integer> storedOperands;

    public MemoryOperation() {
        this.storedOperands = new ArrayDeque<>();
    }

    @Override
    public void addOperand(int operand) {
        this.storedOperands.push(operand);
    }

    @Override
    public boolean isCompleted() {
        return false;

    }

    @Override
    public int getResult() {
        return storedOperands.pop();

    }
}
