package E01_Vehicle;

public interface Vehicle {
    String drive(double kilometers);
    void refuel(double litres);
}
